﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Nested_For_Loops__and_2D_Arrays
{
    internal class Program
    {
        static int[,] matrix =
        {
            {1, 2, 3, },
            {4, 5, 6, },
            {7, 8, 9, }
        };
        static void Main(string[] args)
        {
            foreach (int item in matrix)
            {
                Console.Write(item + " ");
            }

            Console.WriteLine("\nAlso use nested for loops to achieve the same results");
            for (int i = 0; i < matrix.GetLength(0); i++)
            {
                for (int j = 0; j < matrix.GetLength(1); j++)
                {
                    if (i == j)
                    {
                        Console.Write(matrix[i, j] + " ");
                    }
                    else
                    {
                        Console.Write(" ");
                    }
                }
                Console.WriteLine("");
            }
            

            /*for (int i = 0;i < matrix.GetLength(0); i++)
            {
                Console.WriteLine(matrix[i,i]);
            }*/
            // one for loop can also achieve that

            for (int i = 0,  j = matrix.GetLength (1) - 1; i < matrix.GetLength(0); i++, j--)
            {                              
                    Console.WriteLine(matrix[i, j]);   
            }
            Console.Read();
        }
    }
} 