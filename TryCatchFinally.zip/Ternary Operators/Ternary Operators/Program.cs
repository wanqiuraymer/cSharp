﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ternary_Operators
{
    internal class Program
    {
        static void Main(string[] args)
        {
            /*Console.WriteLine("What is the temperature?");
            string temp = Console.ReadLine();
            int temp1=Convert.ToInt32(temp);
            string stateOfMatter = temp1 < 0 ? "Solid" : stateOfMatter = temp1 < 100 ? "liquid" : "gas";
            Console.WriteLine($"The form is {stateOfMatter}.");
            Console.Read();*/

            Console.WriteLine("What is the temperature?");
            string userInput = Console.ReadLine();
            bool success = int.TryParse(userInput, out int temp2);
            if (success)
            {
                string result = temp2 <= 15 ? "It is too cold here" : temp2 >= 16 && temp2 <= 28 ? "It is okay." : "It is hot here.";
            }
            else
            {
                Console.WriteLine("Not a valid temperature");
            }
            

            /*else if (temp2 <= 15) 
            {
                Console.WriteLine("It is too cold here");
            }
            else if (temp2>=16 && temp2 <= 28)
            {
                Console.WriteLine("It is okay");
            }
            else
            {
                Console.WriteLine("It is hot here");
            }*/
            Console.Read();
        }
       
    }
}
