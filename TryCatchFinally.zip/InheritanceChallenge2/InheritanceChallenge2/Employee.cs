﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InheritanceChallenge2
{
    internal class Employee
    {
        protected string LastName { get; set; }
        protected string FirstName { get; set; }
        protected double Salary { get; set; }
        public Employee() 
        {
            LastName = "Raymer";
            FirstName = "Wanqiu";
            Salary = 69000.35;
        }
        public Employee(string lastName, string firstName, double salary) 
        { 
            this.LastName = lastName;
            this.FirstName = firstName;
            this.Salary = salary;
        }
        public virtual void Work()
        {
            Console.WriteLine("I'm working.");
        }
        public void Pause()
        {
            Console.WriteLine("I'm having a break!");
        }
    }
}
