﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InheritanceChallenge2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Employee employee1 = new Employee("Millers", "Chris", 48009.21);
            TeamLead teamLead1 = new TeamLead("Traverse", "Norris", "Grace",79000.32);
            TeamMemberAndIntern teamMemberAndIntern1= new TeamMemberAndIntern(20,20,"Solom","Mickie",20002.35);
            teamLead1.Lead();
            teamMemberAndIntern1.Work();
            teamMemberAndIntern1.Learn();
            Console.ReadKey();
        }
    }
}
