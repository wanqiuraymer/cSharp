﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InheritanceChallenge2
{
    internal class TeamMemberAndIntern:Employee
    {
        protected int WorkingHours { get; set; }
        protected int SchoolHours { get; set;}
        public TeamMemberAndIntern(int workingHours, int schoolHours, string lastName, string firstName, double salary) : base(lastName, firstName, salary) 
        {
            this.SchoolHours = schoolHours;
            this.WorkingHours = workingHours;
        }

        public void Learn() 
        {
            Console.WriteLine("I'm learning for {0}",SchoolHours);
        }
        public override void Work()
        {
            Console.WriteLine("I'm only working {0}", WorkingHours);

        }
    }
}
