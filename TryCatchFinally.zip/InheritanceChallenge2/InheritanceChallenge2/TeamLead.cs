﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InheritanceChallenge2
{
    internal class TeamLead:Employee
    {
        protected string CompanyCar {  get; set; }
        public TeamLead() { }
        public TeamLead(string companyCar, string lastName, string firstName, double salary):base (lastName,firstName,salary)
        {
            this.CompanyCar = companyCar;
        }
        public void Lead()
        {
            Console.WriteLine("My name is {0} {1}. I'm a leader!",FirstName, LastName);
        }

    }
}
