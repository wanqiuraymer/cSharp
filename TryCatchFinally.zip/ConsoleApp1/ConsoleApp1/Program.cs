﻿using System;
using System.Collections.Generic;
using System.Diagnostics.Eventing.Reader;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int counter = 0;
            string userEnter ="";
            while (userEnter.Equals(""))
            {
                Console.WriteLine("Please press Enter as the students enter the bus.");
                userEnter = Console.ReadLine();
                counter++;
                Console.WriteLine($"{counter} students have entered the bus.\n");
            }
           
            Console.Read();
        }
    }
}
