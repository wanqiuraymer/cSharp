﻿using System;
using System.Collections.Generic;
using System.Diagnostics.Eventing.Reader;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Schema;

namespace Challenge_if_statement_2
{
    internal class Program
    {
        static int highscore = 100;
        static string player = "Josh";
        static void Main(string[] args)
        {
            Register();
            Console.Read();
            
        }
        public static void Register() 
        {
            Console.WriteLine("What is your name?");
            string playerName = Console.ReadLine();
            Console.WriteLine("What is your score?");
            int scores = Convert.ToInt32(Console.ReadLine());

            if (scores > highscore)
            {
                highscore = scores;
                player = playerName;
                Console.WriteLine($"New higscore is {highscore}");
                Console.WriteLine($"New highscore holder is {player}");
            }
            else
            {
                Console.WriteLine($"The old highscore of {highscore} could not be broken and is still held by {player}");
            }
        }
    }
}
