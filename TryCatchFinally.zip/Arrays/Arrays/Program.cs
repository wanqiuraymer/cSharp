﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Arrays 
{ 

    internal class Program
    {
        static void Main(string[] args)
        {
            int[] grades = { 10, 13, 17, 20, 19 };
            Console.WriteLine($"The length of grades {grades.Length}");
            Console.ReadKey();
            Console.WriteLine("What is the new value?");
            string input = Console.ReadLine();
            bool success = int.TryParse(input, out int newValue);
            Console.WriteLine(newValue);
            if (success)
            {
                grades[0] = newValue;
                Console.WriteLine(grades[0]);
            }
            else 
            {
                Console.WriteLine("Wrong type.");
            }
           
            Console.ReadKey();
        }
    }
}
