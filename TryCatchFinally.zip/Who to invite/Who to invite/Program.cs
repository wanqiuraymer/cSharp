﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Who_to_invite
{
    internal class Program
    {
        static void Main(string[] args)
        {
            var allFriends = new List<string> { "Sandra", "Joe", "Maria", "Angelina", "Carlos", "Andrew", "Michelle", "Eric", "Noah", "Sarah" };
            var guests = GuestsList(allFriends, 4);
            foreach (var name in guests)
            {
                Console.WriteLine(name);
            }
            Console.Read();
        }
        public static List<string> GuestsList(List<string> takeList, int count)
        {
            if (count > takeList.Count || count <=0)
            {
                throw new ArgumentOutOfRangeException("count", "Guest cannot be more than friends list");
            }
            var buffer = new List<string>(takeList);
            var makingList = new List<string>();
            while (makingList.Count < count)
            {
                string Guest1 = GuestFinder(buffer);
                makingList.Add(Guest1);
                buffer.Remove(Guest1);
            }
            return makingList;
        }
        public static string GuestFinder (List<string> takeList)
        {
            string shortName = takeList[0];
            for (int i = 0; i < takeList.Count; i++)
            {
                if (takeList[i].Length < shortName.Length)
                {
                    shortName=takeList[i];
                }
            }
            return shortName;
        }
    }
}
