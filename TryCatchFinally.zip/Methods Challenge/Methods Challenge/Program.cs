﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Methods_Challenge
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string friend1 = "Frank";
            string friend2 = "Sandy";
            string friend3 = "Lily";

            GreetFriend(friend1);
            GreetFriend(friend2);
            GreetFriend(friend3);
            Console.Read();
        }
        public static void GreetFriend(string friend)
        {
            Console.WriteLine($"Hi {friend}, my friend!");
        }
        

    }
}
