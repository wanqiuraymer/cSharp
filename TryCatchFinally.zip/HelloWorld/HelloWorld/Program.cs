﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HelloWorld
{
    internal class Program
    {
        static void Main(string[] args)
        {
            
            Console.Write("Enter a string here.\n");
            string userInput = Console.ReadLine();
            Console.Write("Enter the character to search.\n");
            char characterToSearch = Console.ReadLine()[0];
            int characterIndex = userInput.IndexOf(characterToSearch);
            Console.WriteLine("The character {0}'s index is {1}", characterToSearch, characterIndex);
            Console.Write("Enter your first name: ");
            string firstName = Console.ReadLine();
            Console.Write("Enter your last name: ");
            string lastName = Console.ReadLine();
            string fullName = string.Concat(firstName, " ",lastName);


         

            Console.Read();
        }
    }
}
