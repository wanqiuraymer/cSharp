﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;

namespace Hashtables
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //creata a hashtable
            Hashtable studentsTable = new Hashtable();
            Student stu1 = new Student(100, "Maria", 4.0f);
            Student stu2 = new Student(200, "Denis", 3.5f);
            Student stu3 = new Student(300, "Drake", 3.9f);
            Student stu4 = new Student(400, "Maureen", 2.9f);
            Student stu5 = new Student(500, "Casey", 3.8f);

            // store data in a hashtable
            studentsTable.Add(stu1.Id, stu1);
            studentsTable.Add(stu2.Id, stu2);
            studentsTable.Add(stu3.Id, stu3);
            studentsTable.Add(stu4.Id, stu4);
            studentsTable.Add(stu5.Id, stu5);

            /*Student storedValue = (Student)studentsTable[100]; // casting data type to type Student; retrieve data from hashtable 
            Student storedValue2 = (Student)studentsTable[stu2.Id];*/

            //retrieve all values from a hashtable
            /*foreach (DictionaryEntry entry in studentsTable) 
            { 
                Student temp = (Student)entry.Value;
                Console.WriteLine(temp.Id);
                Console.WriteLine(temp.Name);
            }*/
            foreach (Student value in studentsTable.Values)
            {

            }

            //Console.WriteLine(storedValue.Name);
            Console.Read();
        }
        
    }
}
