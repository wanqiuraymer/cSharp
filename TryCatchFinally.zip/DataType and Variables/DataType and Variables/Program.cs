﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataType_and_Variables
{
    internal class Program
    {
        const string myBday = "09/03/1984";
        static void Main(string[] args)
        {
           
            Console.WriteLine($"My birthday is always going to be{myBday}");
            Console.Read();

        }
    }
}
