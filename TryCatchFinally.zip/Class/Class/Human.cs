﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Class
{
    internal class Human
    { //member variables
        private string firstName;
        private string lastName;
        private string eyeColor;
        private int age; //initial value for integer is 0


        // default constructor
        public Human()
        {
            Console.WriteLine("Constructor called. object created");
        }
        // parameterized constructor
        public Human(string firstName)
        {
            this.firstName = firstName;
        }
        public Human(string firstName, string lastName)
        {
            this.lastName = lastName;
            this.firstName = firstName;
        }

        public Human(string firstName, string lastName, string eyeColor)
        {
            this.lastName = lastName;
            this.firstName = firstName;
            this.eyeColor = eyeColor;
        }  

        public Human(string firstName, string lastName, string eyeColor, int age) 
        {
            this.lastName = lastName;
            this.firstName = firstName;
            this.eyeColor = eyeColor;
            this.age = age;
        } 
        //member method
        public void IntroduceMyself() 
        {
            if (age != 0 && eyeColor != null && lastName != null && firstName != null)
            {
                Console.WriteLine("Hi, I'm {0} {1}. My eye color is {2} and I'm {3} year(s) old.", firstName, lastName, eyeColor, age);
            }
            else if (eyeColor != null && firstName != null && lastName != null)
            {
                Console.WriteLine("Hi, I'm {0} {1}. My eye color is {2}.", firstName, lastName, eyeColor);
            }
            else if (firstName != null && lastName != null)
            {
                Console.WriteLine("Hi, I'm {0} {1}.", firstName, lastName);
            }
            else if (firstName != null)
            {
                Console.WriteLine("Hi, I'm {0}.", firstName);
            }

           
            
            
            
            
        }
    }
}
