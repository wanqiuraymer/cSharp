﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Class
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Human Jodie = new Human("Jodie","Martin","brown",32); //call constructor
            Jodie.IntroduceMyself();  // call object of the class
            Human Natasha = new Human("Natasha","Hasse","blue");
            Natasha.IntroduceMyself();
            Human Sarah = new Human("Sarah", "Fleming");
            Sarah.IntroduceMyself();
            Human Noah = new Human("Noah");
            Noah.IntroduceMyself();
            Human basicHuman = new Human();
            basicHuman.IntroduceMyself();
           
            Console.ReadKey();

        }



    }
}
