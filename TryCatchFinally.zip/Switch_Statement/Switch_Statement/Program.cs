﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Switch_Statement
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int age = 25;
            switch (age)
            {
                case 21:
                    Console.WriteLine("Good to go!");
                    break;
                case 19:
                    Console.WriteLine("Too young");
                    break;
                default:
                    Console.WriteLine("great!");
                    break;
            }
            

            if (age == 21)
            {
                Console.WriteLine("Good to go!");
            }
            else if (age == 19)
            {
                Console.WriteLine("Too yound");
            }
            else 
            {
                Console.WriteLine("great!");
            }
            string username = "Denis";
            switch (username)
            {
                case "Denis":
                    Console.WriteLine("username is Denis");
                    break;
                case "Sandy":
                    Console.WriteLine("username is Sandy");
                    break;
                default:
                    Console.WriteLine("username unknown");
                    break;
            }
            Console.Read();
        }
    }
}
