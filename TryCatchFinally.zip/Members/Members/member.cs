﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Members
{
    internal class member
    {
        private string memberName;
        private string jobTitle;
        public int age;
        private int salary;


        //member property; property starts with capital letter
        public string JobTitle { get; set; }

        //public methods - can be called from other classes
        public void Introducing (bool isFriend)
        {
            if (isFriend) 
            {
                SharingPrivateInfo();
            }
            else
            {
                Console.WriteLine($"Hi my name is {memberName}, and my job is {jobTitle}.");
            }

        }
        private void SharingPrivateInfo() // private method
        {
            Console.WriteLine($"My salary is {salary}.");

        }

        // member constructor
        public member() 
        {
            age = 30;
            memberName = "Lucy";
            salary = 60000;
            jobTitle = "Developer";
            Console.WriteLine("Object created");
        }
        // member  finalizer - destructor
        ~member() 
        {
            // cleanup statements only use when needed
            Console.WriteLine("Deconstruction of member object");
        }

    }
}
