﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InheritanceIntroduction
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Radio myRadio = new Radio(false, "Sony"); // create object
            myRadio.SwitchOff(); //method of parent class (base class)
            myRadio.ListenToRadio(); // method of child class

            TV myTV = new TV(false, "TCL");
            myTV.SwitchOn();
            myTV.WatchTV();
            Console.Read();
        }
    }
}
   
