﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InheritanceIntroduction
{
    internal class Radio : ElectricalDevice
    {
        //child class
        public Radio(bool isOn, string brand) : base(isOn, brand) 
        { 

        }
       
        public void ListenToRadio()
        {
            if (IsOn)
            {
                Console.WriteLine("Enjoy the radio!");
            }
            else 
            {
                Console.WriteLine("The raido is off!");
            }
        }
    }
}
