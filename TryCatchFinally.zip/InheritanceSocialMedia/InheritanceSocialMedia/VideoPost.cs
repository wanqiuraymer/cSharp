﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InheritanceSocialMedia
{
    internal class VideoPost : Post
    {
        //fields
        protected bool isPlaying = false;
        protected int currDuration = 0;

        public string VideoURL { get; set; }
        public int Length {  get; set; }
        public VideoPost() { }
        public VideoPost (string title, string sendByUsername, string videoURL, int length,bool isPublic) 
        {
            this.ID = GetNextID();
            this.Title = title;
            this.SendByUsername = sendByUsername;
            this.IsPublic = isPublic;
            this.Length = length;
            this.VideoURL = videoURL;
        }
        public override string ToString()
        {
            return String.Format("{0} - {1} - sent by {2} - located at {3}, duration {4} minutes", this.ID, this.Title, this.SendByUsername, this.VideoURL, this.Length);
        }
    }
}
