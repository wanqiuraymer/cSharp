﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InheritanceSocialMedia
{
    internal class ImagePost : Post // ImagePost derives from Post and adds a property (ImageURL) and two constructors
    {
        public string ImageURL { get; set; } //location of the Image
        public ImagePost() 
        { 

        }
        public ImagePost(string title, string sendByUsername, string imageURL, bool isPublic) 
        {
            // inherited from Post class
            this.ID = GetNextID();
            this.Title = title;
            this.SendByUsername = sendByUsername;
            this.IsPublic = isPublic;

            this.ImageURL = imageURL; //only for ImagePost class

        }
        public override string ToString()
        {
            return String.Format("{0} - {1} - sent by {2} - located at {3}", this.ID, this.Title, this.SendByUsername, this.ImageURL);
        }




    }
}
