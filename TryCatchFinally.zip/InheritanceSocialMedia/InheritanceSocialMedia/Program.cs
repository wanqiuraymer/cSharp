﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InheritanceSocialMedia
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Post post1 = new Post("What a Day!", true,"Wanqiu");
            Console.WriteLine(post1.ToString());
            ImagePost imagePost1 = new ImagePost("Fall Pictures", "Noah","https://google.com",true);
            Console.WriteLine(imagePost1.ToString());
            VideoPost videoPost1 = new VideoPost("Romance on the Farm", "Adam", "https://doboku.net", 25, true);
            Console.WriteLine(videoPost1.ToString());
            Console.Read();
        }
    }
}
