﻿using System;
using System.Collections.Generic;
using System.Diagnostics.Eventing.Reader;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InheritanceSocialMedia
{
    internal class Post
    {
        private static int currentPostId;  //field
        protected int ID { get; set; }// protected property can only be used by Post class and deriving classes
        protected string Title { get; set; }
        protected string SendByUsername { get; set; }
        protected bool IsPublic { get; set; }
        public Post() // default constructor; if a derived class does not invoke a base-class constructor explicitly, the default constructor is called implicitly.
        {
            ID = 0;
            Title = "My First Post";
            IsPublic = true;
            SendByUsername = "Gordon Smith";
        }
        public Post(string title, bool isPublic, string sendByUsername) //instance constructor
        {
            this.ID = GetNextID(); //call the method
            this.Title = title;
            this.IsPublic = isPublic;
            this.SendByUsername = sendByUsername;
        }
        protected int GetNextID()   //method
        {
            return ++currentPostId;
        }
        public void Update(string title, bool isPublic) //method to update the post
        {
            this.Title = title;
            this.IsPublic = isPublic;
        }


        //System.Object. // a class from System,we inherit

        public override string ToString() // override a method from system. object class
        {
            return String.Format( "{0} - {1} - sent by {2}",this.ID,this.Title, this.SendByUsername);// format a string
        }

    }
}
