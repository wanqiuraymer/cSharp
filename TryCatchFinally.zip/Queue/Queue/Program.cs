﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Queue
{
    internal class Program
    {
        static Order[] AmazonOrders()
        {
            Order[] orders = new Order[]
            {
                    new Order (100,1),
                    new Order (219,3),
                    new Order (304,10)
            };
            return orders;
        }
        static Order[] ShoptifyOrders()
        {
            Order[] orders = new Order[]
            {
                new Order (105, 5),
                new Order (201, 9),
                new Order (324,2)
            };
            return orders;
        }
        static void Main(string[] args)
        {
            Queue<Order> orderQueue = new Queue<Order>();
            foreach (Order o in AmazonOrders())
            {
                orderQueue.Enqueue(o);
            }
            foreach (Order o in ShoptifyOrders())
            {
                orderQueue.Enqueue(o);
            }
            while (orderQueue.Count > 0)
            {
                Order currentOrder = orderQueue.Dequeue();
                currentOrder.ProcessedOrder();
            }
            Console.Read();

        }
    }
}
