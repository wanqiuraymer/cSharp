﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Multi_Dimensional_Arrays
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //int[,] array2D; // declare 2d array
            int[,] array2D = new int[,]
            {
                {1,2,3}, {4,5,6}, {7,8,9}
            };
            int[,,] array3D = new int[,,]
            {
                {
                    {1,2}, {3,4}, {5,6}
                },
                {
                    {7,8}, {9,10}, {11,12}
                }
            };
            Console.WriteLine(array2D[2,0]);
            Console.WriteLine($"array3D [1,1,1] is {array3D[1,1,1]}");
            Console.Read();
            string[,] stringArray2D = new string[3, 2] { { "one", "two" }, { "three", "four" }, { "five", "six" } }; // 3 rows and 2 entries per row
            stringArray2D[1, 1] = "chicken"; // change value
            int dimensions = stringArray2D.Rank; // .Rank can find out how many dimensions an array has
        }

    }
} 
