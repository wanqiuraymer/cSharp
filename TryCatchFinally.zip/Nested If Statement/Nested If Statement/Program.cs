﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace Nested_If_Statement
{
    internal class Program
    {
        static string userName; //global variables
        static string password; //global variables
        static void Main(string[] args)
        {
            Registration();
            Login();
            Console.Read();
        }
        public static void Registration ()
        {
            Console.WriteLine("Enter a user name to register:");
            userName = Console.ReadLine();
            Console.WriteLine("Create a password:");
            password = Console.ReadLine();
            Console.WriteLine("Registration Completed!");
            Console.WriteLine("----------------------------------");
        }
        public static void Login()
        {
            Console.WriteLine("Please enter your username: ");
            
            if (userName == Console.ReadLine())
            {
                Console.WriteLine("Please enter your password: ");
                if (password == Console.ReadLine())
                {
                    Console.WriteLine($"Congrulation {userName}! Your are logged in.");
                }
                else
                {
                    Console.WriteLine("Login failed, wrong password.");
                }
            }
            else
            {
                Console.WriteLine("Sorry, the user name doesn't match our record.");
            }
            
            
        }

    }
}
