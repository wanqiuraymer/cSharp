﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Operators
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("What is the temperature now?");
            string userInput = Console.ReadLine();
            int temperature;
            int parsedValue;
            if(int.TryParse(userInput, out parsedValue))
            {
                temperature = parsedValue;
            }
            else
            {
                temperature = 0;
                Console.WriteLine("Temperature entered not a number. Temperature set to 0");
            }
            if (temperature > 20){
                Console.WriteLine("You don't need your coat.");
            }else if (temperature >10){
                Console.WriteLine("Take your coat with you. You might need it.");
            }else if (temperature > 5) {
                Console.WriteLine("Definitely need your coat.");
            }else{
                Console.WriteLine("Stay inside!");
            }
            Console.Read();
        }
    }
}
