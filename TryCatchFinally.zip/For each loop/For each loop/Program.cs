﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace For_each_loop
{
    internal class Program
    {
        static void Main(string[] args)
        {
            /*int[] nums = new int[10];
            for (int i =0; i<10; i++)
            {
                nums[i] = i+10;
            }
            for (int j=0; j<nums.Length;j++)
            {
                //Console.WriteLine($"Element {j} is {nums[j]}");
                Console.Write(nums[j] + " ");
            }
            foreach (int k in nums)
            {
                Console.Write(k+ " ");
            }
            Console.Read();*/
            string[] friends = new string[5];
            for (int fr = 0; fr < 5; fr++)
            {
                friends[fr] = "friend" + Convert.ToString(fr + 1);
            }
            
            foreach (string i in friends)
            {
                Console.WriteLine($"Hello, {i}");
            }
            Console.Read();
        }
    }
}
