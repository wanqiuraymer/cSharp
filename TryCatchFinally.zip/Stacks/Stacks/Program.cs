﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Stacks
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Stack<int> newStack = new Stack<int>();
            newStack.Push(1);
            newStack.Push(90);
            newStack.Push(3);
            newStack.Push(23);
            newStack.Push(5);
            newStack.Push(77);
            newStack.Push(54);
            newStack.Push(8);
            Console.WriteLine(newStack.Peek());
            while (newStack.Count > 0) {
                int poppedItem = newStack.Pop();
            }
            Console.WriteLine(newStack.Count);
            int[] number = new int[] { 9, 2, 3, 7, 8, 10, 11, 12, 13 };
            Stack<int> stack = new Stack<int>();
            for (int i = 0; i < number.Length; i++)
            {
                stack.Push(number[i]); 
            }
            while (stack.Count > 0)
            {
                Console.Write(stack.Pop() + " ");
            }
            
            Console.Read();
        }
    }
}
