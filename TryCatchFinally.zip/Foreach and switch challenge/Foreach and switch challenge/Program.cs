﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Foreach_and_switch_challenge
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Thank you for using this application. Please enter any value");
            string userInput = Console.ReadLine();
            Console.WriteLine("What data type do you think it is? \nPress 1 for String\nPress 2 for Integer\nPress 3 for Boolean");
            int dataNew = Convert.ToInt32(Console.ReadLine());
            int counter = 0;
            
            switch (dataNew)
            {
                case 1:

                    foreach (char ch in userInput)
                    {
                        string cha=ch.ToString();
                        bool dataCov = int.TryParse(cha, out int num);
                        if (dataCov)
                        {
                            Console.WriteLine("Not a valid string.");
                            break;
                        }
                        counter ++;

                    }
                    if (counter == userInput.Length)
                    {
                        Console.WriteLine("It is a valid string.");
                    }
                    break;
                case 2:
                    foreach (char ch in userInput)
                    {
                        string cha=ch.ToString();
                        bool dataCov = int.TryParse(cha, out int num);
                        if (dataCov == false)
                        {
                            Console.WriteLine("Not a valid integer.");
                            break;
                        }
                        counter++;

                    }
                    if (counter == userInput.Length)
                    {
                        Console.WriteLine("It is a valid string.");
                    }
                    break;
                case 3:
                    if (userInput.ToLower() == "true" || userInput.ToLower() == "false")
                    {
                        Console.WriteLine("Valid Boolean");

                    }
                    else 
                    {
                        Console.WriteLine("Invalid Boolean");
                    }
                    break;
                    /*foreach (char ch in userInput)
                    {
                        string cha = ch.ToString();
                        bool dataCov = int.TryParse(cha, out int num);
                        if (dataCov == false)
                        {
                            Console.WriteLine("Not a valid integer.");
                            break;
                        }
                        counter++;

                    }
                    if (counter == userInput.Length)
                    {
                        Console.WriteLine("It is a valid string.");
                    }
                    break;*/
            }
            Console.Read();

            
        }
      }
            }


     











