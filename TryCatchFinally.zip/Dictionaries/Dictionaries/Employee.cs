﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dictionaries
{
    internal class Employee
    {
        public int Age  { get; set; }
        public string Name { get; set; }
        public string Role { get; set; }
        public float Rate {  get; set; }
        public float Salary 
        {
            get 
            {
                return Rate * 8 * 360;
            } 
        }
        public Employee(string name, int age, string role, float rate)
        {
            this.Name = name;
            this.Age = age;
            this.Role = role;
            this.Rate = rate;
        }
    }
}
