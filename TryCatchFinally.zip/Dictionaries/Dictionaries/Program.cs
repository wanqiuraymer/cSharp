﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dictionaries
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Employee[] employees =
            {
                new Employee ("Gwyn",65,"CEO",200),
                new Employee ("Joe", 35,"Manager",25),
                new Employee ("Petra", 28, "Secretary", 18),
                new Employee ("Alex", 45, "Senior Developer", 70),
                new Employee ("Ernest", 22, "Intern", 8),
            };
            Dictionary <string, Employee> employeesDir = new Dictionary<string, Employee> ();
            foreach (Employee emp in employees) 
            {
                employeesDir.Add (emp.Name, emp);
            }
            string KeyToUpdate = "Petra";
            if (employeesDir.ContainsKey(KeyToUpdate))
            {
                employeesDir[KeyToUpdate] = new Employee("Petra", 29, "HR", 20);
                Console.WriteLine("Employee with name: {0} was updated.", KeyToUpdate);
            }
            string keyToRemove = "Ernest";
            if (employeesDir.Remove(keyToRemove))
            {
                Console.WriteLine("Employee with name: {0} was removed!", keyToRemove);
            }
            Console.WriteLine("enter a name: ");
            string key = Console.ReadLine();
            if (employeesDir.ContainsKey(key))
            {
                Employee empl = employeesDir[key];
                Console.WriteLine("Employee Name {0}, Age {1}, Role {2}, Salary {3}", empl.Name, empl.Age, empl.Role, empl.Salary);
            }
            else
            {
                Console.WriteLine("Can't find this person.");
            }
            Employee result = null; 
            
            if (employeesDir.TryGetValue(key, out result))
            {
                Console.WriteLine("Value Retrieved!");
                Console.WriteLine("Employee Name: {0}, Age: {1}, Role: {2}, Salary: {3}", result.Name, result.Age, result.Role, result.Salary);
            }
            else { Console.WriteLine("This person does not exist."); }
            Console.Read();
        }
    }
}
