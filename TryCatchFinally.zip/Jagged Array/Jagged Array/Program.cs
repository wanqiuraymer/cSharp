﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;

namespace Jagged_Array
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int[][] jaggedArray = new int[3][]; //declare jagged array

            jaggedArray[0] = new int[5];
            jaggedArray[1] = new int[3];
            jaggedArray[2] = new int[2];


            jaggedArray[0] = new int[] {2,3,4,5,7,11 };
            jaggedArray[1] = new int[] { 8, 7, 11 };
            jaggedArray[2 ] = new int[] { 12, 54};

            //alternative way:
            int[][] jaggedArray2 = new int[][]
            {
                new int []{ 2, 3, 4, 5, 7, 11 },
                new int []{ 14, 19, 1 },
                new int [] { 23, 39, 65 }
            };

            for (int i = 0; i < jaggedArray2.Length; i++) 
            { 
                for (int j = 0; j < jaggedArray2[i].Length; j++)
                {
                    Console.WriteLine(jaggedArray2[i][j]);
                    
                }
            }
            string[] joesfamily = new string[] { "Martha", "Robert" };

            string[][] friendsArrays = new string[][]
            {
                new string []{"Dan", "Lucy" },
                new string []{"Cidny", "Denis"},
                new string []{"Don", "Solomon"},
                joesfamily //store a separate array in the jagged array
            };
            for (int i = 0; i < friendsArrays.Length; i++)
            {
                for (int j = 0;j < friendsArrays[i].Length;j++)
                {
                    
                            Console.WriteLine("Hi {0} ", friendsArrays[i][j] );
                            
                    
                }
            }

            Console.Read();


        }
    }
}
