﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Interface1
{
    internal class Ticket : IEquatable<Ticket> // use interface
    {
        public int DurationInHours {  get; set; }
        public Ticket(int durationInHours) 
        { 
            DurationInHours = durationInHours;
        }
        public bool Equals(Ticket other) // check the Ticket comaparing to other ticket
        {
            return this.DurationInHours == other.DurationInHours;
        }
    }
}
