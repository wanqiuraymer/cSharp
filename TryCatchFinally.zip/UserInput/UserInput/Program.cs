﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UserInput
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Please enter the first number");
            string input1= Console.ReadLine();
            int num1 = Int32.Parse(input1);
            Console.WriteLine("Please enter the second number");
            string input2 = Console.ReadLine();
            int num2 = Int32.Parse (input2);
            Console.WriteLine($"The sum of these two number is {num1 + num2}.");
            Console.Read();

           

        }
    }
}
