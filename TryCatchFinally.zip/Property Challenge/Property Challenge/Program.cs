﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace Property_Challenge
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Surface area = new Surface(3,4);
            Console.WriteLine ("Front surface is {0}", area.FrontSurface);
            Console.Read();

        }
    }
}
