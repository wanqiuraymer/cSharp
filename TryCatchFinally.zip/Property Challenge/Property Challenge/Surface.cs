﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Remoting.Messaging;
using System.Text;
using System.Threading.Tasks;

namespace Property_Challenge
{
    internal class Surface
    {
        private int height;
        private int length;

        public Surface(int height, int length)
        {
            this.height = height;
            this.length = length;
        }
        public int FrontSurface 
        {
            get { return height * length; }
        }
        
    }
}
