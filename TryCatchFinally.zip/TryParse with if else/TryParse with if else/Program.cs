﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TryParse_with_if_else
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string numericString = "128";
            int parsedValue;
            bool success = int.TryParse(numericString, out parsedValue);
            if (success)
            {
                Console.WriteLine($"Successful! ParsedValue is {success}");
            }
            else
            {
                Console.WriteLine("Parsing failed");
            }
           
           
            Console.Read();
        }
    }
}
