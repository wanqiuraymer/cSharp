﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Params_Keyword
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int min = MinV2(3,10,-5,-20,40,60,-2);
            Console.WriteLine($"The smamllest number is {min}");
            Console.ReadKey();
        }
        public static int MinV2(params int[] minValue) 
        { 
            int num = int.MaxValue;
            foreach (int i in minValue)
            {
                if (num > i)
                {
                    num = i;
                }
            }
            return num;
        }
    }
}
