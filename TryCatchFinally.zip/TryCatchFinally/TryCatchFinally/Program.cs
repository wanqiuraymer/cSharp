﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TryCatchFinally
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int number1 = 34;
            int number2 = 0;

            try
            {
                int division = number1 / number2;
            }
            catch (Exception)
            {
                Console.WriteLine("Cannot be divided by 0");

            }
            finally
            {
                Console.WriteLine("Thank you!");
            }

            Console.Read();

        }

    }
