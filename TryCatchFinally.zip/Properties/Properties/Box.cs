﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Properties
{
    internal class Box
    {
        // member variables
        private int length = 3; // it is not available to program.cs in order to change that, create a method get, and set
        private int height;
        //public int width;
        private int volume;

        /* with getters and setters  we don't give access directly to member variables, we only give access to a method that
        can adjust the variable and decide how we want to hand out the value like the GetVolume method*/
        public void SetLength(int length)
        {
            if (length < 0)
            {
                throw new Exception("Length should be above 0"); // throw new Exception use our own exception
            }
            this.length = length;
        }
        public int Volume
        {
            get 
            {
                return this.length * this.height * Width;

            }
           
        }
        public int Height 
        { 
            get
            {
                return height;
            }
            set
            {
                if (value < 0)
                {
                    height = - value;
                }
                else
                {
                    height= value;
                }
                height = value;
            }
        }
        public Box (int length, int height, int width)
        {
            this.length = length;
            this.height = height;
            Width = width;


        }
        public int Width { get; set; }
        /*public int Width
        {
            get
            {
                return this.width;
            }
            set
            {
                this.width = value;
            }
        }*/
        public int GetLength()
        {
            return this.length;
        }
        public int GetVolume() 
        {
            return this.length * this.height * this.Width;
        }
        public void DisplayInfo()
        {
            Console.WriteLine($"Length is {length}, height is {height}, and width is {Width}, so the volume is {Volume}.");
            Console.Read();
        }
    }
}
