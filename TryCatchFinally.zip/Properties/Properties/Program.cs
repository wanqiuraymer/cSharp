﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Properties
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Box box = new Box(3,4,5); //object or instance of a class 
            // won't work if member variable length is set to private box.length = 3;
           
            Console.WriteLine("Box volume is " + box.Volume);
            Console.WriteLine ("Box width is  " + box.Width);
            box.DisplayInfo();
           

        }
    }
}
