﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VirtualOverride
{
    internal class Dog:Animal
    {
        public bool IsHappy { get; set; }
        public Dog (string name, int age) : base (name, age) 
        {
            IsHappy = true;
        }
        public override void Eat() // simple override of the virtual method Eat
        {
            base.Eat();//call the Eat method from our parent class use the keyword base
        }
        public override void MakeSounds()
        {
            Console.WriteLine("Wuuf!");
        }
        public override void Play()
        {
            if (IsHappy)
            {
                base.Play();
            }
            else
            {
                Console.WriteLine($"{Name} is not happy. It is not playing.");
            }
            
        }
    }
}
 