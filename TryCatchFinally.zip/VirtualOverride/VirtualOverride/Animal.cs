﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VirtualOverride
{
    internal class Animal
    {
        public string Name { get; set; }
        public int Age { get; set; }
        public bool IsHungry { get; set; }
        public Animal(string name, int age)
        {
            this.Name = name;
            this.Age = age;
            this.IsHungry = true; //in our case all animals are hungry by default
        }
        public virtual void MakeSounds() // virtual method can be overridden by classes inherit from Animal
        {

        }
        public virtual void Eat()
        {
            if (IsHungry)
            {
                Console.WriteLine($"{Name}, {Age} years old, is eating.It is hungry");
            }
            else 
            {
                Console.WriteLine($"{Name}, {Age} years old, is not eating.It is not hungry");
            }
        }
        public virtual void Play()
        {
            Console.WriteLine($"{Name},{Age} years old, is playing.");
        }
    }
}
