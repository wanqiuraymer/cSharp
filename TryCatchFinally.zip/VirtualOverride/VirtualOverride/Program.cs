﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VirtualOverride
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Dog poodle = new Dog("French Fry", 7);
            poodle.IsHappy = false;
            Console.WriteLine($"{poodle.Name} is {poodle.Age} years old");
            poodle.Eat();
            poodle.Play();
            poodle.MakeSounds();
            Console.Read();
        }
    }
}
