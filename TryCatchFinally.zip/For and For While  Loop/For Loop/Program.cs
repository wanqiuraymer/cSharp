﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace For_Loop
{
    internal class Program
    {
        static void Main(string[] args)
        {
            for (int number = 0;number<20;number++)
            {
               if (number % 2 != 0)
                {
                    Console.WriteLine(number);
                }     
            }
            


            int studentCounter = 0;
            int totalScore = 0;
            int averageScore;
            do
            {
                Console.WriteLine("Please enter student's score: ");
                string input = Console.ReadLine();
                int studentScore = Convert.ToInt32(input);
                totalScore += studentScore;
                studentCounter++;
                averageScore = totalScore / studentCounter;


            }
            while (studentCounter < 4);
            Console.WriteLine($"The average score is {averageScore}.");
            Console.Read();
        }

    }
}
