﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;

namespace Hashtable_Challenge
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Hashtable StudentTable = new Hashtable();
            Students[] students = new Students[5];
            students[0] = new Students(1, "Denis", 88);
            students[1] = new Students(2, "Olaf", 97);
            students[2] = new Students(6, "Ragner", 65);
            students[3] = new Students(1, "Luise", 73);
            students[4] = new Students(4, "Levi", 58);

            
            foreach (Students person in students)
            {
                if (!StudentTable.ContainsKey(person.Id))
                {
                    StudentTable.Add(person.Id,person );
                    Console.WriteLine("Student with ID {0} was added.", person.Id);
                }
                else
                {
                    Console.WriteLine("Sorry, a student with the same ID already exists ID {0}", person.Id);
                }
            }
            Console.Read();

        }
    }
}
