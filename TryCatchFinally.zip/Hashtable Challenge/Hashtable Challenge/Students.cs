﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hashtable_Challenge
{
    internal class Students
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public float GPA { get; set; }
        public Students(int id, string name, float gPA)
        {
           this.Id = id;
           this.Name = name;
           this.GPA = gPA;
        }
    }
}
