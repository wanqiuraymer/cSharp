﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Schema;

namespace Loop_Challenge
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int studentCounter = 0;
            double studentScore =0;
            double totalScore = 0;
            double averageScore =0;
           
            while (studentScore <= 20)
            {
                Console.WriteLine("Enter student's test score. The score is between 0 and 20.  Enter -1 to see the average");
                string teacherInput = Console.ReadLine();
                bool success = double.TryParse(teacherInput, out studentScore);
                if (success == false )
                {
                    Console.WriteLine("Please enter a valid score (only numbers between 0 and 20). Please try again\n");
                    continue;
                }
                
                else if (studentScore == -1) 
                {
                    Console.WriteLine($"The average score is {averageScore}");
                    break;
                }
               

                
                studentCounter++;
                totalScore += studentScore;
                averageScore = Convert.ToDouble(totalScore / studentCounter);
            }
            Console.Read();

        }
    }
}
